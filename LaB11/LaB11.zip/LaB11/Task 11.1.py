from classes.restaurant import Restaurant


def lab_11_1():
    # Создание экземпляра класса ресторана
    restaurant = Restaurant("Чебуречкино", "фастфуд")
    restaurant.describe_restaurant()
    restaurant.open_restaurant()
lab_11_1()